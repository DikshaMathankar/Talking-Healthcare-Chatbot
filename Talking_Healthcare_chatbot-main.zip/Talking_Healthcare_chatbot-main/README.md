# Talking_Healthcare_chatbot
This project is a voice-enabled AI healthcare chatbot built with Python, natural language processing (NLP), and a neural network model. The chatbot listens to user symptoms, predicts the most likely medical condition from a trained dataset, and responds using synthesized speech.
